﻿Configuration AppsConfiguration
{
    param (
        [Bool] $installEkranServer,
        [Bool] $installPGServer,
        [Bool] $installSQLServer,
		[String] $sqlServerType,
        [String] $sqlServerHostname,
        [String] $sqlServerPort,
        [String] $managementToolUrl,
        [String] $subNetPrefix,
        [String] $language,
        [String] $languagePacksUrl,
        [PSCredential] $vmUser,
        [PSCredential] $sqlServerUser,
        [PSCredential] $mtDefaultUser
	)
    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
    
    Node localhost
    {
        Script InstallLanguagePack {
            SetScript = {
                $geoIDs = @{ 'ja-JP' = 122; 'ru-RU' = 203; 'ko-KR' = 134; 'zh-TW' = 237; 'de-DE' = 94; 'tr-TR' = 235; 'pl-PL' = 191; 'es-ES' = 217 }
                $files_location = "$env:USERPROFILE\AppData\Local\Temp"

                [Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls, Ssl3"
                Invoke-WebRequest -Uri $Using:languagePacksUrl\$Using:language.zip -OutFile $files_location\$language.zip -UseBasicParsing
                Expand-Archive -Path $files_location\$language.zip -DestinationPath $files_location\
                $user_sid = ([System.Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
                (Get-Content $files_location\$language\$language.reg).Replace("USER_KEY", $user_sid) | Out-File "$files_location\ekran_user.reg"
                (Get-Content $files_location\$language\$language.reg).Replace("USER_KEY", "DEFAULT_USER") | Out-File "$files_location\default_user.reg"
                (Get-Content $files_location\$language\$language.reg).Replace("USER_KEY", ".DEFAULT") | Out-File "$files_location\default.reg"
                
                lpksetup.exe /i $language /p $files_location\$language\$language.cab /s
                While (Get-Process -Name lpksetup -ErrorAction SilentlyContinue) { Start-Sleep 10 }

                Set-WinUserLanguageList $language, 'en-US' -Force       
                Set-WinHomeLocation -GeoId $geoIDs.$language
                New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\MUI\Settings" -Name "PreferredUILanguages" -PropertyType MultiString -Value $language

                Start-Process reg -ArgumentList "import $files_location\ekran_user.reg"
                Start-Process reg -ArgumentList "import $files_location\default.reg"

                $DefaultHKEY = "HKU\DEFAULT_USER"
                $DefaultRegPath = "C:\Users\Default\NTUSER.DAT"
                Start-Process reg -ArgumentList "load $DefaultHKEY $DefaultRegPath"
                Start-Process reg -ArgumentList "import $env:USERPROFILE\AppData\Local\Temp\default_user.reg"
                
                Set-WinSystemLocale -SystemLocale $language
                Start-Process reg -ArgumentList "unload $DefaultHKEY"
                                
                Restart-Computer -Force -ErrorAction SilentlyContinue
                Start-Sleep 500
            }
            
            TestScript = { 
                $languages_installed = (Get-WmiObject -Class Win32_OperatingSystem).MUILanguages
                if (($Using:language -ne 'en-US') -and ($language -notin $languages_installed)) { $false } else { $true }
            }
            
            GetScript = { @{ Result = 'Language pack is installed' } }
            PsDscRunAsCredential = $vmUser
        }

        Script InstallPostgreSQL {
            SetScript = {
                $fileName = "postgresql-13.1-1-windows-x64.exe"
                $filePath = "$env:TEMP\$fileName"

                Get-Disk | Where-Object partitionstyle -eq 'raw' | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -DriveLetter "G" -UseMaximumSize | Format-Volume -FileSystem NTFS -Confirm:$false
                New-PSDrive -Name "G" -Root "G:\" -PSProvider "FileSystem"
                $dataDir = "G:\PostgreSQL\13\data"

                [Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls, Ssl3"
                Invoke-WebRequest -Uri http://get.enterprisedb.com/postgresql/$fileName -OutFile $filePath -UseBasicParsing
                & "$filePath" --mode unattended --superaccount $Using:sqlServerUser.UserName --superpassword "$($sqlServerUser.GetNetworkCredential().Password)"  --servicepassword "$($sqlServerUser.GetNetworkCredential().Password)" --serverport $Using:sqlServerPort --datadir $dataDir
                While (Get-Process -Name "postgresql-13*") { Start-Sleep 10 }

                if ( -Not $Using:installEkranServer) {
                    New-NetFirewallRule -DisplayName "PostgreSQLServer" -Direction Inbound -LocalPort $Using:sqlServerPort -Protocol TCP -Action Allow
                    $oldConfig = Get-Content -Path $dataDir\pg_hba.conf
                    Set-Content -Value $oldConfig.Replace('127.0.0.1/32', $Using:subNetPrefix) -Path $dataDir\pg_hba.conf -Force
                    Restart-Service -Name "postgresql*" -Force
                }
            }
            
            TestScript = { 
                $PGService = Get-Service -Name "postgresql*" -ErrorAction SilentlyContinue
                if ($Using:installPGServer -and (-not $PGService)) { $false } else { $true }
            }
            
            GetScript = { @{ Result = 'PostgreSQL is installed' } }
            DependsOn = "[Script]InstallLanguagePack"
        }

        Script InstallMSCppRedist {
            SetScript = {
                $fileName = "vc_redist.x64.exe"
                $filePath = "$env:TEMP\$fileName"

                [Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls, Ssl3"
                Invoke-WebRequest -Uri https://download.microsoft.com/download/9/3/F/93FCF1E7-E6A4-478B-96E7-D4B285925B00/vc_redist.x64.exe -OutFile $filePath -UseBasicParsing
                & $filePath '/passive', '/quite'
            }
            
            TestScript = { 
                $MSCppRedist2015 = Get-WmiObject -Class Win32_Product -Filter "Name LIKE '%Visual C++ 2015%'"
                if ($Using:installEkranServer -and (-not $MSCppRedist2015)) { $false } else { $true }
            }
                        
            GetScript = { @{ Result = 'Microsoft Visual C++ 2015 Redistributable has been downloaded' } }
            DependsOn = "[Script]InstallPostgreSQL"
        }

        WindowsFeatureSet ManagementToolRequirements
        {
            Name                    = @("Web-WebServer", "Web-WebSockets", "Web-Asp-Net", "Web-Asp-Net45", "Web-Mgmt-Console")
            Ensure                  = if ($installEkranServer) {'Present'} else { 'Absent' }
            IncludeAllSubFeature    = $true
            DependsOn = "[Script]InstallMSCppRedist"
        } 

        Script TestMSSQLServer {
            SetScript = {
                $connectionString = "Data Source=$Using:sqlServerHostname,$Using:sqlServerPort;User ID=$($Using:sqlServerUser.UserName);Password=$($sqlServerUser.GetNetworkCredential().Password);"
                $errMessage = "There is no connection to the SQL server. Please check that the SQL server is accessible over the network, and that the correct credentials were provided.`
                Log in to the VM and finish installing the Ekran System Application Server manually. You can find the installation file in $env:TEMP\EkranSystem."
                
                try
                {
                    $sqlConnection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString;
                    $sqlConnection.Open();
                    $sqlConnection.Close();
                }
                catch
                {
                    throw $errMessage
                }
            }
            
            TestScript = { -not ((-not $Using:installSQLServer) -and ($Using:sqlServerType -eq 'MSSQL')) }
            GetScript = { @{ Result = 'SQL connection has been tested' } }
            DependsOn = "[WindowsFeatureSet]ManagementToolRequirements"
        }

        Script TestPGServer {
            SetScript = {
                $fileName = "postgresql-13.1-1-windows-x64.exe"
                $filePath = "$env:TEMP\$fileName"
                $errMessage = "There is no connection to the SQL server. Please check that the SQL server is accessible over the network, and that the correct credentials were provided.`
                Log in to the VM and finish installing the Ekran System Application Server manually. You can find the installation file in $env:TEMP\EkranSystem."

                $psqlFile = Test-Path "$env:PROGRAMFILES\PostgreSQL\13\bin\psql.exe"
                if (-not $psqlFile) {
                    [Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls, Ssl3"
                    Invoke-WebRequest -Uri http://get.enterprisedb.com/postgresql/$fileName -OutFile $filePath -UseBasicParsing
                    & "$filePath" --mode unattended --disable-components server,pgAdmin,stackbuilder
                    While (Get-Process -Name "postgresql-13*") { Start-Sleep 10 }
                }
                $env:PGPASSWORD=$($sqlServerUser.GetNetworkCredential().Password)
                $env:PGUSER=$($Using:sqlServerUser.UserName)
                
                try {
                    & "$env:PROGRAMFILES\PostgreSQL\13\bin\psql.exe" --host=$Using:sqlServerHostname --port=$Using:sqlServerPort --command="select now()"
                }
                catch {
                    throw $errMessage
                }
                
                Remove-Item -Path Env:PGPASSWORD
                Remove-Item -Path Env:PGUSER
            }
            
            TestScript = { -not ((-not $Using:installSQLServer) -and ($Using:sqlServerType -eq 'PG')) }
            
            GetScript = { @{ Result = 'SQL connection has been tested' } }
            DependsOn = "[Script]TestMSSQLServer"
        }

        Script CreateMSSQLdatabases {
            SetScript = {
                $collations = @{ 'ja-JP' = 'Japanese_CI_AS'; 'ru-RU' = 'Cyrillic_General_CI_AS'; 'ko-KR' = 'Korean_Wansung_CI_AS'; 'zh-TW' = 'Chinese_Taiwan_Stroke_CI_AS';
                                 'de-DE' = 'Latin1_General_CI_AS'; 'tr-TR' = 'Turkish_CI_AS'; 'pl-PL' = 'Polish_CI_AS'; 'es-ES' = 'Modern_Spanish_CI_AS' }
                $connectionString = "Data Source=$($Using:sqlServerHostname),$($Using:sqlServerPort);User ID=$($Using:sqlServerUser.UserName);" `
                                    + "Password=$($sqlServerUser.GetNetworkCredential().Password);"
                $attempts = 1
                while ($attempts -le 3) {
                    try {
                        $sqlConnection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString
                        $sqlConnection.Open();
                        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
                        $sqlCommand.Connection = $sqlConnection
                        $sqlCommand.CommandText = "SELECT * FROM master.dbo.sysdatabases WHERE NAME = 'EkranActivityDB'"
                        $dbExists = $sqlCommand.ExecuteScalar();
                        if ($dbExists) {
                            $sqlConnection.Close();
                            return
                        }
                        else {
                            $sqlCommand.CommandText = "CREATE DATABASE EkranActivityDB COLLATE $($collations.$Using:language)"
                            $sqlCommand.ExecuteNonQuery();
                            $sqlCommand.CommandText = "CREATE DATABASE EKRANManagementDatabase COLLATE $($collations.$Using:language)"
                            $sqlCommand.ExecuteNonQuery();
                            $sqlCommand.CommandText = "CREATE DATABASE EkranUbaDatabase COLLATE $($collations.$Using:language)"
                            $sqlCommand.ExecuteNonQuery();
                            $sqlConnection.Close();
                        }
                    }
                    catch {
                        Start-Sleep 5
                        $attempts += 1
                    }
                }
            }
            
            TestScript = { 
                if (($Using:sqlServerType -ne 'PG') -and ($Using:language -ne 'en-US')) { $false } else { $true }
            }
            GetScript = { @{ Result = 'SQL databases have been created' } }
            DependsOn = "[Script]TestPGServer"
        }

        Script CreateIniFile {
		    SetScript = {
                if ($Using:installPGServer -and $Using:installEkranServer) {
                    $sqlInstanceName = 'localhost'
                }
                else {
                    $sqlInstanceName = $Using:sqlServerHostname
                }
                $mtAdminCred = $Using:mtDefaultUser
			    $OFS = "`r`n"
                $ConfigText = 
                "[Database]" +$OFS+ `
                "DBType=" + $Using:sqlServerType +$OFS+ `
                "ServerInstance=" + $sqlInstanceName + ":" + $Using:sqlServerPort +$OFS+ `
                "DBName=EkranActivityDB" +$OFS+ `
                "DBUserName=" + $Using:sqlServerUser.UserName +$OFS+ `
                "DBPassword=" + $sqlServerUser.GetNetworkCredential().Password +$OFS+ `
                "UseExistingDatabase=false" +$OFS+ `
				"Authentication=1" +$OFS+$OFS+ `
                "[Admin]" +$OFS+ `
                "AdminPassword=" + $mtAdminCred.GetNetworkCredential().Password +$OFS+$OFS+ `
                "[MT]" +$OFS+ `
                "ServerPath=localhost" +$OFS+ `
                "WebManagementUrl=" + $Using:managementToolUrl

                Set-Content $ConfigText -Path "C:\Windows\Temp\install.ini"
            }
            
            TestScript = {
                $IniFile = Test-Path "C:\Windows\Temp\install.ini"
                if ($Using:installEkranServer -and (-not $IniFile)) { $false } else { $true}
            }
            
            GetScript = { @{ Result = 'EkranServer configuration INI file has been created' } }
            DependsOn = "[Script]CreateMSSQLdatabases"
        }

        Script TestNewPGServer {
            SetScript = {
                for ($i = 0; $i -lt 60; $i++) {
                    $TestPGPort = Test-NetConnection -ComputerName $Using:sqlServerHostname -Port $Using:sqlServerPort
                    if ($TestPGPort.TcpTestSucceeded) {
                        break
                    }
                    Start-Sleep -Seconds 30
                }

                if (-not $TestPGPort.TcpTestSucceeded) {
                        throw "PostgreSQL server cannot be accessed."
                }
            }
            
            TestScript = { -not ($Using:installSQLServer -and ($Using:sqlServerType -eq 'PG') -and (-not $Using:installPGServer)) }
            
            GetScript = { @{ Result = 'SQL connection has been tested' } }
            DependsOn = "[Script]CreateMSSQLdatabases"
        }

        Script InstallEkranSystemApplication {
            SetScript = {

                # Download Ekran System installation package
                $fileName = "EkranSystem-en.zip"
                $filePath = "$env:USERPROFILE\AppData\Local\Temp\$fileName"

                [Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls, Ssl3"
                Invoke-WebRequest -Uri https://download.ekransystem.com/EkranSystem-en.zip -OutFile $filePath -UseBasicParsing

                $destination = "$env:USERPROFILE\AppData\Local\Temp\EkranSystem"
                Expand-Archive -Path $filePath -DestinationPath $destination -Force
                $EkranServerDir = (Get-ChildItem -Path "$env:USERPROFILE\AppData\Local\Temp" -Filter EkranSystem_Server*  -Recurse).Directory
                Copy-Item -Path "C:\Windows\Temp\install.ini" -Destination $EkranServerDir

                # Create IIS certificate for MT
                $cert = New-SelfSignedCertificate -CertStoreLocation 'Cert:\LocalMachine\My' -DnsName "ekransystem"
                New-IISSiteBinding -Name "Default Web Site" -BindingInformation "*:443:" -CertificateThumbPrint $cert.Thumbprint -CertStoreLocation "Cert:\LocalMachine\My" -Protocol https

                # Install Management Tool
                $EkranMtFullPath = (Get-ChildItem -Path $EkranServerDir -Filter EkranSystem_ManagementTool_*).FullName
                & "$EkranMtFullPath" '/S'
                While (Get-Process -Name "EkranSystem*" -ErrorAction SilentlyContinue) { Start-Sleep 10 }

                # Install Ekran Server
                $EkranServerFullPath = (Get-ChildItem -Path $EkranServerDir -Filter EkranSystem_Server_*).FullName
                & "$EkranServerFullPath" '/S'
                While (Get-Process -Name "EkranSystem*" -ErrorAction SilentlyContinue) { Start-Sleep 10 }

                # Install Ekran agent
                While (-not(Get-NetTCPConnection -LocalPort 9447 -State Listen -ErrorAction SilentlyContinue)) { Start-Sleep 10 }
                & "C:\Program Files\Ekran System\Ekran System\Server\WinPackage\agent.exe" '/servername=localhost'
                While (Get-Process -Name "agent*" -ErrorAction SilentlyContinue) { Start-Sleep 10 }
            }
            
            TestScript = {
                $ServerProc = Get-Process -Name "EkranServer" -ErrorAction SilentlyContinue
                if ($Using:installEkranServer -and (-not $ServerProc)) { $false } else { $true }
            }
            
            GetScript = { @{ Result = 'Ekran System Application is installed' } }
            DependsOn = "[Script]TestNewPGServer"
            PsDscRunAsCredential = $vmUser
        } 
    }
}